﻿namespace BL.Pizzeria
{
    public class Cliente
    {
        public int Id { get; set; }
        public string Nombre { get; set; }
        public string Teléfono { get; set; }
    }
}